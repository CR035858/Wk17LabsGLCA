package com.gl.tdms.labwk17d04dem1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.tdms.labwk17d04dem1.entity.Role;



public interface RoleRepository extends JpaRepository<Role, Integer> {

}
