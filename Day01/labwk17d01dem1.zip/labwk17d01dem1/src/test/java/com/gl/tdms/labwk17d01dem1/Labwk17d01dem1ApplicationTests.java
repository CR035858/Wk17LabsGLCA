package com.gl.tdms.labwk17d01dem1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk17d01dem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
