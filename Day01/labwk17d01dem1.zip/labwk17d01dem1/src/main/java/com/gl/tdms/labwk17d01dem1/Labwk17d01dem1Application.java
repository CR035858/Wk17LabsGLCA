package com.gl.tdms.labwk17d01dem1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labwk17d01dem1Application {

	public static void main(String[] args) {
		SpringApplication.run(Labwk17d01dem1Application.class, args);
		System.out.println("Welcome to SpringBoot Web App - Security");
	}

}
